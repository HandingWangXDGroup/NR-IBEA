    %------------------------------- Reference --------------------------------
    % Nan Zheng, Handing Wang*, A Noise-Resistant Infill Sampling Criterion in Surrogate-Assisted
    % Multi-Objective Evolutionary Algorithms, Swarm and Evolutionary Computation.
    %------------------------------- Copyright --------------------------------
    % Copyright (c) 2022 HandingWangXD Group. Permission is granted to copy and
    % use this code for research, noncommercial purposes, provided this
    % copyright notice is retained and the origin of the code is cited. The
    % code is provided "as is" and without any warranties, express or implied.
    %---------------------------- Parameter setting ---------------------------
    % NI    = 100--------The size of population
    % kappa = 0.05------The scaling factor
    % wmax = 20-------The maximum surrogate-assisted search times
    % This code is written by Nan Zheng.
    % Email: Nanszheng@163.com
    
    clc; clear; warning off;
    cd(fileparts(mfilename('fullpath')));
    addpath(genpath(cd));
    
    %% Parameter Setting
    Global.problem = 'DTLZ1';
    Global.N = 100;
    Global.M = 3;
    Global.D = 12;
    Global.lower = zeros(1, Global.D);
    Global.upper = ones(1, Global.D);
    Global.evaluation = 300;
    Global.evaluated = 0;
    Global.Var = sqrt(0.2);
    
    
    kappa = 0.05;
    wmax = 20;
    NI = Global.N;
    %% Initialization
    PopDec = unifrnd(repmat(Global.lower,Global.N,1),repmat(Global.upper,Global.N,1));
    [Population, Global] = INDIVIDUAL(PopDec, Global);
    A1 = Population;
    THETA = 5.*ones(Global.M,Global.D); 
    THETAPF = 5.*ones(1,Global.M - 1);
    THETAIGD = 5.*ones(1,Global.D);
    Pop = Population;
    % Resampling for estimating the performance of denoising
    [denoise, Global] = NoiseEstimation(Population(randperm(NI,1)),4, Global);
    tic;
    clc; fprintf('%s on %d-objective %d-variable (%6.2f%%), %.2fs passed...\n',Global.problem,Global.M,Global.D,Global.evaluated/Global.evaluation*100,toc);
    %% Optimization process
    while Global.evaluated < Global.evaluation
       
       A1Dec = A1.decs;
       % Noise handling
       A1Obj = NoiseHandling(A1, denoise, Global);
       % Objective model construction
       [Model, THETA] = ModelGeneration(A1Obj, A1Dec, denoise, THETA, Global);

       PopDec = Pop.decs;
       PopObj = zeros(NI, Global.M);

       PopObj = ModelPrediction(PopDec, Model, Global);
      %% Surrogate-assisted evolutionary search
       w = 1;
       while w <= wmax
           
           %% Offspring generation
           drawnow();
           MatingPool = TournamentSelection(2,Global.N,-CalFitness(PopObj,kappa));   
           [OffDec,Global] = GA(PopDec(MatingPool',:),Global);
           PopDec = [PopDec;OffDec];
           
           
           [N,~] = size(PopDec);
           PopObj = zeros(N, Global.M);
           
           %% Predicting by objective model
           PopObj = ModelPrediction(PopDec, Model, Global);

           %% Surrogate-assisted environmental selection
            [PopDec, PopObj] = SurrogateEnvironmentSelectionC(PopDec, PopObj, kappa, NI);

           w = w + 1;
       end
       
      %% PF estimation
       ND = NDSort(A1Obj,1); % A1Obj
       ePopObj = A1Obj(ND==1,:);
       [PF, THETAPF] = EstimationPF(ePopObj, THETAPF, 2*NI);
       ePF = [PF;A1Obj];
       ND = NDSort(ePF,1);
       ND1 = ND(1:size(PF,1));
       ePF = PF(ND1==1,:);
       ePF = unique(ePF,'rows');
       
       
       % Condidates selection
       CandidateDec = [];
       CandidateObj = [];
       CandidateMSE = [];
       for i = 1 : size(PopDec, 1)
          dist2 = pdist2(real(PopDec(i,:)),A1.decs); 
          if min(dist2)>1e-5
             CandidateDec = [CandidateDec; PopDec(i,:)];
             CandidateObj = [CandidateObj; PopObj(i,:)];
          end
       end
       
       %% Infill sampling
       if ~isempty(CandidateDec)
           [PopNew,THETAIGD] = InfillSampling(CandidateDec, CandidateObj, 1, ePF, CandidateMSE, A1, THETAIGD);
           [New, Global] = INDIVIDUAL(PopNew, Global);
           A1 = [A1, New];
           % Initial population selection
           Pop = EnvironmentalSelection(A1,NI,kappa);
       else
           % Initial population selection
           Pop = EnvironmentalSelection(A1,NI,kappa);
       end
       clc; fprintf('%s on %d-objective %d-variable (%6.2f%%), %.2fs passed...\n',Global.problem,Global.M,Global.D,Global.evaluated/Global.evaluation*100,toc);
    end
    ND = NDSort(A1.objs,1); 
    OutPopulation = A1(1,ND==1);
    