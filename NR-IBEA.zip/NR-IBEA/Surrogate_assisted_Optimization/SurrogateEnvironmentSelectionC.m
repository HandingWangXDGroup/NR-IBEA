function [SPopDec, SPopObj] = SurrogateEnvironmentSelectionC(PopDec, PopObj, kappa, N)

        %% ����I+�Ļ���ѡ��
        Next = 1 : size(PopDec, 1);
        [Fitness,I,C] = CalFitness(PopObj,kappa);
        while length(Next) > N
            [~,x]   = min(Fitness(Next));
            Fitness = Fitness + exp(-I(Next(x),:)/C(Next(x))/kappa);
            Next(x) = [];
        end
        SPopDec = PopDec(Next,:);
        SPopObj = PopObj(Next,:);
%         MSE = MSE(Next,:);
end