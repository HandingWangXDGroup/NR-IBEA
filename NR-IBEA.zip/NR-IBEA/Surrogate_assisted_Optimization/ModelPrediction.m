function y = ModelPrediction(PopDec, Model, Global)
    
    PopDec = ArrrayDenormalization(PopDec, Global.lower, Global.upper);
    y = zeros(size(PopDec,1),Global.M);
    for i = 1 : Global.M 
        if Model{1,i} == 1
            for j = 1 : size(PopDec,1)
                [y(j,i),~,~] = predictor(PopDec(j,:), Model{2,i});
            end
        else
            y(:,i) = cal_via_net(PopDec, Model{2,i});
        end
    end
    
end