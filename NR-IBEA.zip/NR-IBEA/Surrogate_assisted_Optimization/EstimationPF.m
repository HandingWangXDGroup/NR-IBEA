function [PF, THETAPF] = EstimationPF(objs, THETAPF,N)
    
    objs = unique(objs,'rows');
    Zmin = min(objs,[],1);
    f = sum(abs(objs),2);
    e = objs./repmat(f,1,size(objs,2));
    input = e(:,1:size(objs,2)-1);
    output = f;
    dmodel = dacefit(input,output,'regpoly0','corrgauss',THETAPF,1e-5.*ones(1,size(input,2)),100.*ones(1,size(input,2)));
    THETAPF = dmodel.theta;
    [sample_input, N] = UniformPoint(size(objs,2)*N,size(objs,2));
    
    
    for i = 1 : size(sample_input, 1) 
        [f1(i,1),~,MSE1(i,1)] = predictor(sample_input(i,1:size(input,2)), dmodel);
    end
    PF = sample_input.*repmat(f1,1,size(objs,2));
    for i = 1 : size(Zmin,2)
        if Zmin(1,i) < 0
            down = Zmin(1,i);
            up = 0;
        else
            up = Zmin(1,i);
            down = 0;
        end
        [y,ps] = mapminmax(PF(:,i)',down,up);
        PF(:,i) = y';
    end
end