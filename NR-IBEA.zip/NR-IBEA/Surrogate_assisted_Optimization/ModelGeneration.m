function [Model, THETA] = ModelGeneration(A1Obj, A1Dec, denoise, THETA, Global)

    % RBFN and Kriging probably selection
    Model = cell(2,Global.M);
    % ѡ����ʵ���
    A1Dec = ArrrayDenormalization(A1Dec, Global.lower, Global.upper);
    for i = 1 : Global.M
       dmodel     = construct_rbfn(A1Dec, A1Obj(:,i), size(A1Obj,1));
       ModelRBFN{i}   = dmodel;
    end
    
    for j = 1 : Global.M
        pred_objs(:,j) =  cal_via_net(A1Dec, ModelRBFN{j});
    end
     
    % �����Ƚ�����
    objmax=A1Obj+repmat(5*denoise.std,size(pred_objs,1),1);
    objmin=A1Obj-repmat(5*denoise.std,size(pred_objs,1),1);
    result=pred_objs>objmin&pred_objs<objmax;
    pro = sum(result,1)/size(pred_objs,1);
    
    % ����ѡ��
    for i = 1 : Global.M
        if rand <= pro(i)
            % RBFN ģ�ͽ���
            Model{1,i} = 0;
            Model{2,i} = ModelRBFN{i};
        else
            % Kriging ģ�ͽ���
            Model{1,i} = 1;
            dmodel     = dacefit(A1Dec,A1Obj(:,i),'regpoly0','corrgauss',THETA(i,:),1e-5.*ones(1,Global.D),100.*ones(1,Global.D));
            Model{2,i} = dmodel;
            THETA(i,:) = dmodel.theta;
        end
    end
    
end