function [NewDec,THETAIGD] = InfillSampling(PopDec, PopObj, N, ePF, MSE, A, THETAIGD)
    
    AObjs = A.objs;
    ADecs = A.decs;
    Objs = [ePF; AObjs];
    for i = 1 :size(Objs,2)
        [y, ps] = mapminmax(Objs(:,i)',0,1);
        Objs(:,i) = y';
    end
    NePF = Objs(1:size(ePF,1),:);
    NAObjs = Objs(size(ePF,1)+1:end,:);
    eIGD = [];
    eDecs = [];
    eObjs = [];
    FrontNo    = NDSort(NAObjs,inf);
    Pro = max(FrontNo);
    for i = 1 : max(FrontNo)
        tran = NAObjs((FrontNo == i)',:);
        eDecs = [eDecs;ADecs((FrontNo == i)',:)];
        eObjs = [eObjs;AObjs((FrontNo == i)',:)];
        if size(tran,1) == 1
            inIGD = EstimateIGD(tran,NePF);
            eIGD(size(eIGD,1)+1,1) = inIGD;
        else
            for j = 1 : size(tran,1)
                dist2 = pdist2(real(tran(j,:)),tran); 
                dist2(find(dist2==0)) = NaN;
                [min_cd,idx] = min(dist2);
                eGD = EstimateGD(tran(j,:),NePF);
                eIGD(size(eIGD,1)+1,1) = eGD-(1-FrontNo(i)/Pro)*min_cd;
            end
        end
    end
    dmodel = [];
        while(isempty(dmodel)||isnan(dmodel.beta))
            dmodel = dacefit(eDecs,eIGD,'regpoly0','corrgauss',THETAIGD,1e-5.*ones(1,size(eDecs,2)),100.*ones(1,size(eDecs,2)));
            THETAIGD = dmodel.theta;
        end
        Gbest = min(eIGD);
    for i = 1 : size(PopDec, 1) 
        [pIGD,~,IGDMSE] = predictor(PopDec(i,:), dmodel);
        s         = sqrt(IGDMSE);
        EI(i)     = -(Gbest-pIGD)*normcdf((Gbest-pIGD)/s)-s*normpdf((Gbest-pIGD)/s);
    end
    [~,index] = sort(EI);
    NewDec = PopDec(index(1),:);
    
end


function eIGD = EstimateIGD(Objs,ePF)
   Dis=min(pdist2(ePF,Objs),[],2);
   eIGD=mean(Dis);

end

function score = EstimateGD(Objs,optimum)

    PopObj = Objs;
    if size(PopObj,2) ~= size(optimum,2)
        score = nan;
    else
        Distance = min(pdist2(PopObj,optimum),[],2);
        score    = norm(Distance)/length(Distance);
    end
end
