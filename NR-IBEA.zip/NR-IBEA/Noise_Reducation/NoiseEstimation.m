function [denoise, Global] = NoiseEstimation(Pop,N,Global)
   
    Dec = Pop.dec;
    [Resamples, Global] = INDIVIDUAL(repmat(Dec,N,1), Global);
    Resamples = [Resamples,Pop];
    Obj = Resamples.objs;
    denoise.aver = mean(Obj,1);
    denoise.max = max(abs(repmat(denoise.aver,N+1,1)-Obj),[],1);
    denoise.std = std(Obj, 1);
    
    
end